//
//  ViewController.swift
//  secretContactsBook
//
//  Created by Jai Telang on 01/07/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

